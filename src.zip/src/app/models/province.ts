export interface Province 
    {
        id: number,
        nome: string,
        sigla: string
    }
