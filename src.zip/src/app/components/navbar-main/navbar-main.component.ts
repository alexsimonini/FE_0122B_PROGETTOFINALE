import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth/service/auth.service';
import { ClientiService } from 'src/app/auth/service/clienti.service';
import { Cliente } from 'src/app/models/cliente';

@Component({
  selector: 'app-navbar-main',
  templateUrl: './navbar-main.component.html',
  styleUrls: ['./navbar-main.component.scss']
})
export class NavbarMainComponent implements OnInit {
cliente!: Cliente
  constructor(public authSrv: AuthService, private router: Router, private clienteSrv: ClientiService) { }

  ngOnInit(): void {
  }

  navigaListaUtenti() {
    if (localStorage.getItem('utenteLoggato')) {
      this.router.navigate(['/lista-utenti'])
    }
  }

  navigaListaClienti() {
    if (localStorage.getItem('utenteLoggato')) {
      this.router.navigate(['/lista-clienti'])
    }
  }

  navigaFatture() {
    if (localStorage.getItem('utenteLoggato')) {
      this.router.navigate(['/fattura'])
    }
  }
  logOut() {
    this.authSrv.logout();
    this.router.navigate([''])
  }

  navigaHome(){
    if (localStorage.getItem('utenteLoggato')) {
      this.router.navigate(['/homepage'])

    }
  }
}
