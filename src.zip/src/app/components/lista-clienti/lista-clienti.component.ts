import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ClientiService } from 'src/app/auth/service/clienti.service';
import { Cliente } from 'src/app/models/cliente';
import { DettaglioClienteComponent } from '../dettaglio-cliente/dettaglio-cliente.component';
import { Fattura } from '../../models/fattura';
import { FattureService } from 'src/app/auth/service/fatture.service';

@Component({
  selector: 'app-lista-clienti',
  templateUrl: './lista-clienti.component.html',
  styleUrls: ['./lista-clienti.component.scss']
})
export class ListaClientiComponent implements OnInit {
form!:FormGroup;
pagina:number = 1
pageSize = 10
data!: Cliente[]
fatture!: Fattura[]
  constructor(private fb: FormBuilder, private clientiSrv: ClientiService, private router: Router, private fattureSrv: FattureService) { }

  ngOnInit(): void {
    this.recuperaClienti()
  }

  recuperaClienti(){
    this.clientiSrv.Allclienti(0).subscribe(res =>{
      this.data = res.content
      console.log(this.data)
    })
  }

cancellaUtente(id:number){
this.clientiSrv.cancella(id).subscribe(()=>{
  this.recuperaClienti()
})
}


modificaCliente(id:number){
  this.clientiSrv.modifica(id,this.data).subscribe(res=>{
    this.form = res.content
    console.log(this.form)
    this.router.navigate(['dettaglio-cliente/' + id])
  })

}

fatturaCliente(id:number){
  this.fattureSrv.fatturaCliente(id).subscribe((res)=>{
    this.fatture = res.content;
    this.router.navigate(['fattura/cliente/' + id]);
  })
}

aggiungiCliente(id:number) {
  this.clientiSrv.salva(id).subscribe(()=>{
    this.form
    this.router.navigate(['dettaglio-cliente/'])
  })
}
}
