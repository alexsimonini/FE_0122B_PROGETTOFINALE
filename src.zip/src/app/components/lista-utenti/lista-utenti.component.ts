import { Component, OnInit } from '@angular/core';
import { UtentiService } from 'src/app/auth/service/utenti.service';
import { Utente } from 'src/app/models/utente';

@Component({
  selector: 'app-lista-utenti',
  templateUrl: './lista-utenti.component.html',
  styleUrls: ['./lista-utenti.component.scss']
})
export class ListaUtentiComponent implements OnInit {
users!: Utente[]
pagination!:number
collectionSize!: number
  constructor(private utentiSrv: UtentiService) { }

  ngOnInit(): void {
    this.utentiSrv.getUsers(1).subscribe(res =>{
      this.users = res.content
      console.log(this.users)
      
    })

    
  }
}


