import { Component, OnInit, Pipe } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FattureService } from 'src/app/auth/service/fatture.service';
import { Fattura } from 'src/app/models/fattura';




@Component({
  selector: 'app-dettaglio-fattura',
  templateUrl: './dettaglio-fattura.component.html',
  styleUrls: ['./dettaglio-fattura.component.scss']
})
export class DettaglioFatturaComponent implements OnInit {

  fatturaCliente!: Fattura[]
  i: number = 0
  response:any
  date:any
  id!: number

  constructor(private route: ActivatedRoute, private fattureSrv: FattureService, private router: Router) { }

  ngOnInit(): void {
    this.recuperaFatturaCliente()
  }

  recuperaFatturaCliente(){
    this.route.params.subscribe(async(params)=>{
      const id = +params ['id'];
      this.fattureSrv.fatturaCliente(id).subscribe(f=>{
        this.fatturaCliente = f.content

    })
    })
  }
  cambiaPagina(pagina: number) {
    this.fattureSrv.stampaFatture(pagina).subscribe(res=>{
      this.response = res
    })
  }
  counter(i:number){
    return new Array(i)
  }

}
