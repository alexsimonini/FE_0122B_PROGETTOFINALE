import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { FattureService } from 'src/app/auth/service/fatture.service';
import { Cliente } from 'src/app/models/cliente';
import { Fattura } from 'src/app/models/fattura';
import { NgForm, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-nuova-fattura',
  templateUrl: './nuova-fattura.component.html',
  styleUrls: ['./nuova-fattura.component.scss']
})
export class NuovaFatturaComponent implements OnInit {

  form!: FormGroup;
  fattura!: Fattura;
  stato!: any[]
  id: any
  cliente!: Cliente

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private fattureSrv: FattureService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const id = +params['id'];
      this.fattureSrv.fatturaId(id).subscribe(res => {
        this.fattura = res
      })
    })
    this.salva(this.form)
    this.formInit()
  }

  formInit() {


    this.form = this.fb.group({
      id: new FormControl(''),
      data: new FormControl(''),
      numero: new FormControl(''),
      anno: new FormControl(''),
      importo: new FormControl(''),
      stato: new FormControl(),
      cliente: new FormControl(),
      idCliente: new FormControl(),

    })
  }

getStato() {
    this.fattureSrv.statoFattura().subscribe(stato => {
      this.stato = stato
    })
  }

  salva(form:any) {
    this.fattura.id = this.form.value.id,
    this.fattura.data = this.form.value.data,
    this.fattura.numero = this.form.value.numero,
    this.fattura.anno = this.form.value.anno,
    this.fattura.importo = this.form.value.importo,
    this.fattura.stato = this.form.value.stato,
    this.fattura.cliente =  this.form.value.cliente.ragioneSociale
}
}
